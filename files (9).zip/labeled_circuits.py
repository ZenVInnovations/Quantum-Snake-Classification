"""
labeled_circuits.py — clean, well-annotated circuit diagrams for the paper.

Each figure has: the circuit, a title explaining what it does, and a legend
box explaining every gate used. Rendered at 4 qubits for legibility (the
experiments used 8, identical structure).
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import pennylane as qml
from pennylane import numpy as pnp

NQ = 4
rng = np.random.default_rng(0)
qml.drawer.use_style("pennylane")

INK = "#1A1A1A"
BOXBG = "#F4F1EA"


def add_legend(fig, entries, y0=0.02):
    """Add a labeled legend box explaining the gates."""
    txt = "GATE LEGEND:    " + "     ".join(entries)
    fig.text(0.5, y0, txt, ha="center", va="bottom", fontsize=17,
             color=INK, fontweight="bold",
             bbox=dict(boxstyle="round,pad=1.1", facecolor=BOXBG,
                       edgecolor="#C8C2B4", linewidth=1))


# =====================================================================
# FIGURE 1 — VQC
# =====================================================================
def fig_vqc():
    dev = qml.device("default.qubit", wires=NQ)

    @qml.qnode(dev)
    def vqc(x, w):
        qml.AmplitudeEmbedding(x, wires=range(NQ), normalize=True, pad_with=0.0)
        qml.StronglyEntanglingLayers(w, wires=range(NQ))
        return qml.expval(qml.PauliZ(0))

    x = rng.random(2 ** NQ)
    shape = qml.StronglyEntanglingLayers.shape(n_layers=2, n_wires=NQ)
    w = pnp.array(0.5 * rng.standard_normal(shape))

    fig, ax = qml.draw_mpl(vqc, decimals=2, style="pennylane", fontsize=26)(x, w)
    fig.set_size_inches(9.5, 5.0)
    fig.suptitle("Figure 1(a).  Variational Quantum Classifier (VQC)",
                 fontsize=25, fontweight="bold", y=1.04)
    ax.set_title(
        "Photo features are amplitude-encoded, then processed by trainable "
        "rotations and entanglers (repeated L times), then qubit 0 is measured.\n"
        "The Rot angles are the LEARNED parameters (72 of them at 8 qubits, "
        "L = 3). Prediction: venomous if \u27e8Z\u2080\u27e9 > 0.",
        fontsize=18, pad=18)
    add_legend(fig, [
        "|\u03a8\u27e9 = amplitude encoding (load features)",
        "Rot(a,b,c) = trainable 3-angle rotation",
        "\u25cf\u2013\u2295 = CNOT (entangles two qubits)",
        "M = measurement of \u27e8Z\u27e9",
    ])
    fig.subplots_adjust(bottom=0.20, top=0.78)
    fig.savefig("clean_vqc.png", dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("saved clean_vqc.png")


# =====================================================================
# FIGURE 2 — QCNN
# =====================================================================
CONV_P, POOL_P = 6, 3


def conv(p, a, b):
    qml.RY(p[0], wires=a); qml.RY(p[1], wires=b)
    qml.CNOT(wires=[a, b])
    qml.RY(p[2], wires=a); qml.RY(p[3], wires=b)
    qml.CNOT(wires=[b, a])
    qml.RY(p[4], wires=a); qml.RY(p[5], wires=b)


def pool(p, s, k):
    qml.CRZ(p[0], wires=[s, k]); qml.CRX(p[1], wires=[s, k]); qml.RZ(p[2], wires=k)


def fig_qcnn():
    dev = qml.device("default.qubit", wires=NQ)
    stages, active = [], list(range(NQ))
    while len(active) > 1:
        cp = [(active[i], active[i + 1]) for i in range(0, len(active), 2)]
        pp = [(active[i + 1], active[i]) for i in range(0, len(active), 2)]
        stages.append((cp, pp))
        active = [active[i] for i in range(0, len(active), 2)]

    @qml.qnode(dev)
    def qcnn(x, p):
        qml.AmplitudeEmbedding(x, wires=range(NQ), normalize=True, pad_with=0.0)
        i = 0
        for cp, pp in stages:
            for a, b in cp:
                conv(p[i:i + CONV_P], a, b); i += CONV_P
            for s, k in pp:
                pool(p[i:i + POOL_P], s, k); i += POOL_P
        return qml.expval(qml.PauliZ(0))

    npar = sum(len(c) * CONV_P + len(p) * POOL_P for c, p in stages)
    x = rng.random(2 ** NQ)
    p = pnp.array(0.5 * rng.standard_normal(npar))

    fig, ax = qml.draw_mpl(qcnn, decimals=2, style="pennylane", fontsize=26)(x, p)
    fig.set_size_inches(10.0, 5.0)
    fig.suptitle("Figure 1(b).  Quantum Convolutional Neural Network (QCNN)",
                 fontsize=25, fontweight="bold", y=1.04)
    ax.set_title(
        "Convolution gates act on neighbouring qubit pairs (like an image "
        "filter); pooling then discards half the qubits.\n"
        "The register shrinks 4 \u2192 2 \u2192 1 (8 \u2192 4 \u2192 2 \u2192 1 in "
        "the experiments). Discarded qubits appear as idle lines. 45 parameters "
        "at 8 qubits.",
        fontsize=18, pad=18)
    add_legend(fig, [
        "|\u03a8\u27e9 = amplitude encoding",
        "RY = trainable Y-rotation",
        "\u25cf\u2013\u2295 = CNOT (convolution)",
        "CRZ / CRX / RZ = pooling (then discard a qubit)",
    ])
    fig.subplots_adjust(bottom=0.20, top=0.78)
    fig.savefig("clean_qcnn.png", dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"saved clean_qcnn.png ({npar} params at {NQ}q)")


# =====================================================================
# FIGURE 3 — QSVM
# =====================================================================
def fig_qsvm():
    dev = qml.device("default.qubit", wires=NQ)

    @qml.qnode(dev)
    def kernel(x1, x2):
        qml.AngleEmbedding(x1, wires=range(NQ), rotation="Y")
        qml.adjoint(qml.AngleEmbedding)(x2, wires=range(NQ), rotation="Y")
        return qml.probs(wires=range(NQ))

    x1 = np.array([2.41, 0.87, 1.57, 2.98])
    x2 = np.array([0.92, 1.44, 2.10, 0.55])

    fig, ax = qml.draw_mpl(kernel, decimals=2, style="pennylane", fontsize=26)(x1, x2)
    fig.set_size_inches(8.5, 4.8)
    fig.suptitle("Figure 1(c).  Quantum Kernel circuit (QSVM)",
                 fontsize=25, fontweight="bold", y=1.05)
    ax.set_title(
        "Encode photo A with RY rotations, then UN-encode photo B with the "
        "reverse (adjoint, shown by \u2020).\n"
        "If A = B the two cancel exactly and the kernel = 1. This circuit has "
        "ZERO trainable parameters \u2014 the reason it avoids barren plateaus.",
        fontsize=18, pad=18)
    add_legend(fig, [
        "RY(x) = encode a feature as a rotation",
        "RY(x)\u2020 = adjoint (un-encode / reverse)",
        "M = measure; kernel = P(all qubits read 0)",
    ])
    fig.subplots_adjust(bottom=0.21, top=0.76)
    fig.savefig("clean_qsvm.png", dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    k_ab = float(kernel(x1, x2)[0]); k_aa = float(kernel(x1, x1)[0])
    print(f"saved clean_qsvm.png  K(A,B)={k_ab:.3f} K(A,A)={k_aa:.3f}")


if __name__ == "__main__":
    fig_vqc()
    fig_qcnn()
    fig_qsvm()
