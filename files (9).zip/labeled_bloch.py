"""
labeled_bloch.py — Bloch sphere figures, honestly covering all three methods.

Panel 1: angle encoding (QSVM) - works perfectly on the Bloch sphere.
Panel 2: the VQC/QCNN encoding BEFORE entanglement - still single-qubit states.
Panel 3: WHY entanglement breaks the single-qubit Bloch picture (state collapses
         to the sphere centre).
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pennylane as qml

TEAL = "#0F6E56"; AMBER = "#E8A33D"; CORAL = "#D85A30"; PURPLE = "#6B5FBF"
INK = "#1A1A1A"; GRID = "#CCCCCC"


def bloch_of(gate_fn, wires=1, target=0):
    """Bloch (x,y,z) of one qubit after applying gate_fn."""
    dev = qml.device("default.qubit", wires=wires)

    @qml.qnode(dev)
    def c():
        gate_fn()
        return [qml.expval(qml.PauliX(target)),
                qml.expval(qml.PauliY(target)),
                qml.expval(qml.PauliZ(target))]
    return np.array([float(v) for v in c()])


def draw(ax, vec, title, color, faded=False):
    u = np.linspace(0, 2 * np.pi, 40); v = np.linspace(0, np.pi, 20)
    xs = np.outer(np.cos(u), np.sin(v)); ys = np.outer(np.sin(u), np.sin(v))
    zs = np.outer(np.ones_like(u), np.cos(v))
    ax.plot_surface(xs, ys, zs, color="lightsteelblue", alpha=0.10)
    ax.plot_wireframe(xs, ys, zs, color=GRID, linewidth=0.35,
                      rstride=4, cstride=4, alpha=0.55)
    t = np.linspace(0, 2 * np.pi, 120)
    ax.plot(np.cos(t), np.sin(t), 0, color=GRID, lw=0.8, alpha=0.8)
    for vv, lab in [((1.3, 0, 0), "x"), ((0, 1.3, 0), "y"), ((0, 0, 1.3), "z")]:
        ax.plot([0, vv[0]], [0, vv[1]], [0, vv[2]], color=INK, lw=0.7, alpha=0.45)
        ax.text(vv[0] * 1.08, vv[1] * 1.08, vv[2] * 1.08, lab, fontsize=14, alpha=0.6)
    ax.text(0, 0, 1.16, r"$|0\rangle$", ha="center", fontsize=17, weight="bold")
    ax.text(0, 0, -1.28, r"$|1\rangle$", ha="center", fontsize=17, weight="bold")

    x, y, z = vec
    length = np.sqrt(x*x + y*y + z*z)
    if faded or length < 0.15:
        # entangled/mixed: show a dot at the centre, no clear arrow
        ax.scatter([0], [0], [0], color=CORAL, s=90, marker="o",
                   edgecolors="white", linewidths=1.5, zorder=10)
        ax.text2D(0.5, -0.02, "state sits at the CENTRE\n(no single-qubit arrow)",
                  transform=ax.transAxes, ha="center", fontsize=15,
                  color=CORAL, weight="bold")
    else:
        ax.quiver(0, 0, 0, x, y, z, color=color, lw=3, arrow_length_ratio=0.16)
        ax.scatter([x], [y], [z], color=color, s=55,
                   edgecolors="white", linewidths=1.2, zorder=10)
        ax.text2D(0.5, -0.02, f"arrow length = {length:.2f}",
                  transform=ax.transAxes, ha="center", fontsize=15, color=color)
    ax.set_title(title, fontsize=16, pad=1)
    ax.set_xlim([-1, 1]); ax.set_ylim([-1, 1]); ax.set_zlim([-1, 1])
    ax.set_box_aspect([1, 1, 1]); ax.set_axis_off()
    ax.view_init(elev=18, azim=32)


# =====================================================================
# FIGURE A — angle encoding ladder (QSVM). Bloch works perfectly here.
# =====================================================================
def figure_A():
    thetas = [0.0, np.pi / 4, np.pi / 2, 3 * np.pi / 4, np.pi]
    labs = [r"$\theta=0$", r"$\theta=\pi/4$", r"$\theta=\pi/2$",
            r"$\theta=3\pi/4$", r"$\theta=\pi$"]
    cols = [TEAL, TEAL, AMBER, CORAL, CORAL]
    fig = plt.figure(figsize=(11, 4.2))
    fig.suptitle(
        "Figure 2(a).  Angle encoding (used in the QSVM):  a feature value "
        r"$x\in[0,\pi]$ rotates one qubit via $R_Y(x)$",
        fontsize=22, fontweight="bold", y=1.03)
    for i, (th, lab, col) in enumerate(zip(thetas, labs, cols)):
        ax = fig.add_subplot(1, 5, i + 1, projection="3d")
        draw(ax, bloch_of(lambda th=th: qml.RY(th, 0)), lab, col)
    fig.text(0.5, 0.0, "The qubit sweeps cleanly from |0\u27e9 (north pole) to "
             "|1\u27e9 (south pole). Each qubit is independent \u2014 the Bloch "
             "sphere describes it exactly.",
             ha="center", fontsize=16, color=INK)
    fig.subplots_adjust(bottom=0.10, top=0.82)
    fig.savefig("clean_bloch_encoding.png", dpi=300, bbox_inches="tight",
                facecolor="white")
    plt.close(fig)
    print("saved clean_bloch_encoding.png")


# =====================================================================
# FIGURE B — why entanglement breaks the single-qubit Bloch picture
# =====================================================================
def figure_B():
    fig = plt.figure(figsize=(10.5, 4.6))
    fig.suptitle(
        "Figure 2(b).  Why the VQC and QCNN cannot be shown as single-qubit "
        "Bloch spheres",
        fontsize=22, fontweight="bold", y=1.03)

    # panel 1: qubit after RY only (before entangling) - clear arrow
    ax1 = fig.add_subplot(1, 3, 1, projection="3d")
    draw(ax1, bloch_of(lambda: qml.RY(1.0, 0)),
         "1. after RY(1.0)\n(before entangling)", TEAL)

    # panel 2: apply a CNOT with another qubit -> qubit 0 becomes entangled
    def entangled():
        qml.Hadamard(0)
        qml.CNOT(wires=[0, 1])   # Bell state: qubit 0 now maximally entangled
    ax2 = fig.add_subplot(1, 3, 2, projection="3d")
    draw(ax2, bloch_of(entangled, wires=2, target=0),
         "2. after CNOT entangles it\n(VQC/QCNN use many CNOTs)",
         CORAL, faded=True)

    # panel 3: explanation text panel
    ax3 = fig.add_subplot(1, 3, 3)
    ax3.axis("off")
    ax3.text(0.5, 0.5,
             "Once a qubit is ENTANGLED with\nothers, it no longer has its own\n"
             "definite arrow \u2014 its Bloch vector\ncollapses toward the centre\n"
             "of the sphere.\n\n"
             "The VQC and QCNN entangle all\ntheir qubits (via CNOT gates) and\n"
             "use amplitude encoding, which\nspreads information across the\n"
             "whole multi-qubit state.\n\n"
             "So they cannot be drawn as\nseparate Bloch spheres \u2014 this is\n"
             "a real property of quantum\nmechanics, not a limitation of\nthe software.",
             ha="center", va="center", fontsize=16, color=INK,
             bbox=dict(boxstyle="round,pad=0.7", facecolor="#F4F1EA",
                       edgecolor="#C8C2B4", linewidth=1.2))
    fig.subplots_adjust(top=0.84)
    fig.savefig("clean_bloch_entanglement.png", dpi=300, bbox_inches="tight",
                facecolor="white")
    plt.close(fig)
    print("saved clean_bloch_entanglement.png")


# =====================================================================
# FIGURE C — the kernel overlap mechanism (QSVM), on the Bloch sphere
# =====================================================================
def figure_C():
    ta, tb = 2.41, 0.87
    fig = plt.figure(figsize=(10.5, 4.3))
    fig.suptitle(
        "Figure 2(c).  How the QSVM kernel measures photo similarity (qubit 0)",
        fontsize=22, fontweight="bold", y=1.04)
    ax1 = fig.add_subplot(1, 4, 1, projection="3d")
    draw(ax1, bloch_of(lambda: None), r"1. start at $|0\rangle$", INK)
    ax2 = fig.add_subplot(1, 4, 2, projection="3d")
    draw(ax2, bloch_of(lambda: qml.RY(ta, 0)),
         r"2. $R_Y(\theta_A)$" + "\nencode photo A", TEAL)
    ax3 = fig.add_subplot(1, 4, 3, projection="3d")
    draw(ax3, bloch_of(lambda: (qml.RY(ta, 0), qml.adjoint(qml.RY)(tb, wires=0))),
         r"3. $R_Y^\dagger(\theta_B)$" + "\nun-encode photo B", CORAL)
    ax4 = fig.add_subplot(1, 4, 4, projection="3d")
    draw(ax4, bloch_of(lambda: (qml.RY(ta, 0), qml.adjoint(qml.RY)(ta, wires=0))),
         "if A = B: back to |0\u27e9\n(kernel = 1.0)", PURPLE)

    dev = qml.device("default.qubit", wires=1)

    @qml.qnode(dev)
    def ov(a, b):
        qml.RY(a, wires=0); qml.adjoint(qml.RY)(b, wires=0)
        return qml.probs(wires=0)
    fig.text(0.5, 0.0,
             f"kernel = P(measure |0\u27e9):   different photos \u2192 "
             f"{float(ov(ta, tb)[0]):.3f}      identical photos \u2192 "
             f"{float(ov(ta, ta)[0]):.3f}",
             ha="center", fontsize=16, color=INK)
    fig.subplots_adjust(bottom=0.08, top=0.80)
    fig.savefig("clean_bloch_kernel.png", dpi=300, bbox_inches="tight",
                facecolor="white")
    plt.close(fig)
    print("saved clean_bloch_kernel.png")


if __name__ == "__main__":
    figure_A()
    figure_B()
    figure_C()
